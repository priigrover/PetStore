<?php
    session_start();

    if (!isset($_SESSION['username'])){ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--    <link href="images/logo.jpg" rel="shortcut icon"> -->
    <title>Fiddo Fiddle</title>
    <script src="https://kit.fontawesome.com/420415cd2e.js" crossorigin="anonymous"></script>
    <!-- core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">  
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">

</head><!--/head-->
        
<!--*********************************************START OF NAVIGATION BAR****************************************--> 
<body>
          
     
<nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="index.php" style="display:flex;justify-content:center;align-items:center">
                        <h4  class="wow fadeInDown" style=" color:#FFF;font-size:2em">
                        <i class="fas fa-paw" style="color:#8A8A00;"></i>    Fido Fiddle</h4>
                    </a>
                </div>

                <div class="collapse navbar-collapse navbar-right wow fadeInDown" style="display:flex;justify-content:center;align-items:center">
                    <ul class="nav navbar-nav" style=" color:#FFF;font-size:1.2em">
                        <li><a href="index.php"><i class="fa fa-home" style="margin-right:0.5rem"></i>Home</a></li>
                        <li ><a href="about-us.php">About Us</a></li>
                        <li><a href="available.php">Available Products</a></li>
                        <li class="active"><a href="contacts.php">Contacts</a></li>

                    </ul>
                </div>
            </div>
            <!--/.container-->
        </nav>
        <!--/nav-->
<!--*********************************************START OF CONTACT INFO****************************************-->

<br><br>
<div class="container" style="width:100%;height:65.9vh;display:flex;justify-content:center;align-items:center">
        <section id="contact-info">
                <center><span style="font-size:30px; font-weight:bold; font-family:verdana; color:navy;">How to Reach Us?</span></center>
                <br><br>

            <div class="left wow fadeInDown">
                
               <div class="col-md-6">
                <img src="images/logo.jpg" class="img-responsive pull-right" />
               </div> 
               <div class="col-md-6">
                <p class="lead">
                    <br>
                    <p><span style="font-size:20px; font-weight:bold; font-family:verdana; color:#8B8B00;">Fido Fiddle</span><br>
                    <br><b>Address:Street XYZ New Delhi, India</b> <b><br>Tel/Phone:</b> +91 9930839140 / +91 8368217696<b><br>Email Address:</b> fidofiddle@gmail.com</p>
                    <hr>
                    <span style="font-size:18px; font-weight:bold; font-family:verdana; color:Violet;">We are open</span>
                    <p><b>MONDAY TO FRIDAY -- 8:00AM - 5:00PM</b></p>
                </p>
                <hr>
                <table style="width:80px;">
                    <tr>
                        <td><a href="http://www.facebook.com"><img data-toggle="tooltip" src="images/ico/Facebook.png" class="img-responsive" /></a></td>
                        <td><a href="http://www.instagram.com"><img src="images/ico/icons_Instagram.png" class="img-responsive" /></a></td>
                        <td><a href="http://www.twitter.com"><img src="images/ico/Twitter.png" class="img-responsive" /></a></td>
                        <td><a href="http://www.youtube.com"><img src="images/ico/YouTube.png" class="img-responsive" /></a></td>
                    </tr>
                </table>

                </div>
            </div>
        
        </section>
</div>
<br><br>
<!--*************************************************** FOOTERS **********************************************-->

<?php include('includes/footer.php');?><!--/#footer-->
    <?php include('loginModal.php')?>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>

<?php 

} else if(isset($_SESSION['username'])) { 

    include('includes/admin.php');

} ?>